package com.college.moviealert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieAlertSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieAlertSystemApplication.class, args);
	}

}
